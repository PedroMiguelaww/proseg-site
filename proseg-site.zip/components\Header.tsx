"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Menu, X, PhoneCall } from "lucide-react";

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="bg-[#0B2545] text-white sticky top-0 z-50 border-b border-[#134074] shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <div className="relative w-70 h-24">
              <Image 
                src="/images/logoBranca.png" 
                alt="Logo Proteção Veicular" 
                fill 
                className="object-contain" 
                priority
              />
            </div>
          </Link>

          {/* Menu Desktop */}
          <nav className="hidden md:flex items-center space-x-8 font-medium text-sm">
            <Link href="/" className="text-gray-200 hover:text-[#EEF4F8] transition-colors">
              Início
            </Link>
            <Link href="/protecao-veicular" className="text-gray-200 hover:text-[#EEF4F8] transition-colors">
              Proteção Veicular
            </Link>
            <Link href="/rastreador" className="text-gray-200 hover:text-[#EEF4F8] transition-colors">
              Rastreador
            </Link>
           <Link href="/quem-somos" className="text-gray-200 hover:text-[#EEF4F8] transition-colors">
              Quem Somos
              </Link>
            <Link href="/contato" className="text-gray-200 hover:text-[#EEF4F8] transition-colors">
            </Link>
          </nav>

          {/* Botão de Ação / WhatsApp Desktop */}
          <div className="hidden md:flex items-center">
            <a
              href="https://wa.me/5583921450783"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-[#134074] hover:bg-[#EEF4F8] hover:text-[#0B2545] text-white px-5 py-2.5 rounded-xl font-semibold text-sm transition-all duration-300 border border-[#EEF4F8]/10 shadow-sm"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Central 24h</span>
            </a>
          </div>

          {/* Botão do Menu Mobile (Hambúrguer) */}
          <div className="flex md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 rounded-xl bg-[#134074] text-white hover:bg-[#134074]/80 transition-colors focus:outline-none"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Menu Mobile Dropdown */}
      {isOpen && (
        <div className="md:hidden bg-[#0B2545] border-b border-[#134074] px-4 pt-2 pb-6 space-y-3 animate-fadeIn">
          <Link 
            href="/" 
            onClick={() => setIsOpen(false)}
            className="block px-3 py-2 rounded-lg text-base font-medium text-gray-200 hover:bg-[#134074]"
          >
            Início
          </Link>
          <Link 
            href="/protecao-veicular" 
            onClick={() => setIsOpen(false)}
            className="block px-3 py-2 rounded-lg text-base font-medium text-gray-200 hover:bg-[#134074]"
          >
            Proteção Veicular
          </Link>
          <Link 
            href="/rastreador" 
            onClick={() => setIsOpen(false)}
            className="block px-3 py-2 rounded-lg text-base font-medium text-gray-200 hover:bg-[#134074]"
          >
            Rastreador
          </Link>
          <Link 
            href="/sobre" 
            onClick={() => setIsOpen(false)}
            className="block px-3 py-2 rounded-lg text-base font-medium text-gray-200 hover:bg-[#134074]"
          >
            Quem Somos
          </Link>
          <Link 
            href="/contato" 
            onClick={() => setIsOpen(false)}
            className="block px-3 py-2 rounded-lg text-base font-medium text-gray-200 hover:bg-[#134074]"
          >
            Fale Conosco
          </Link>
          <div className="pt-2">
            <a
              href="https://wa.me/5583900000000"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full bg-[#134074] text-white py-3 rounded-xl font-semibold text-sm border border-[#EEF4F8]/10"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Central 24h</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
}